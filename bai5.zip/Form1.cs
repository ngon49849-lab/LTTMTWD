﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using baitap_b5.Model; // Đã sửa namespace trỏ về đúng thư mục Model của bạn

namespace baitap_b5
{
    public partial class Form1 : Form
    {
        // Khởi tạo context.
        // LƯU Ý: Nếu class trong file Model1.cs của bạn tên khác (ví dụ StudentContextDB),
        // hãy đổi 'new Model1()' thành 'new StudentContextDB()'.
        Model1 context = new Model1();

        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // Lấy danh sách Khoa và Sinh viên
                // LƯU Ý: Đảm bảo tên bảng trong Model1 là Faculties và Students
                List<Faculty> listFalcultys = context.Faculty.ToList();
                List<Student> listStudent = context.Student.ToList();

                FillFalcultyCombobox(listFalcultys);
                BindGrid(listStudent);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FillFalcultyCombobox(List<Faculty> listFalcultys)
        {
            this.cmbKhoa.DataSource = listFalcultys;
            this.cmbKhoa.DisplayMember = "FacultyName";
            this.cmbKhoa.ValueMember = "FacultyID";
        }

        private void BindGrid(List<Student> listStudent)
        {
            dgvSinhVien.Rows.Clear();
            foreach (var item in listStudent)
            {
                int index = dgvSinhVien.Rows.Add();
                dgvSinhVien.Rows[index].Cells[0].Value = item.StudentID;
                dgvSinhVien.Rows[index].Cells[1].Value = item.FullName;

                // Kiểm tra null để tránh lỗi nếu sinh viên không thuộc khoa nào
                if (item.Faculty != null)
                    dgvSinhVien.Rows[index].Cells[2].Value = item.Faculty.FacultyName;

                dgvSinhVien.Rows[index].Cells[3].Value = item.AverageScore;
            }
        }

        private void ResetForm()
        {
            txtMaSV.Clear();
            txtHoTen.Clear();
            txtDiemTB.Clear();
            if (cmbKhoa.Items.Count > 0) cmbKhoa.SelectedIndex = 0;
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtMaSV.Text) || string.IsNullOrWhiteSpace(txtHoTen.Text) || string.IsNullOrWhiteSpace(txtDiemTB.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (txtMaSV.Text.Length != 10)
            {
                MessageBox.Show("Mã số sinh viên phải có 10 kí tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                Student dbStudent = context.Student.FirstOrDefault(p => p.StudentID == txtMaSV.Text);
                if (dbStudent != null)
                {
                    MessageBox.Show("Mã sinh viên đã tồn tại!", "Thông báo");
                    return;
                }

                Student s = new Student();
                s.StudentID = txtMaSV.Text;
                s.FullName = txtHoTen.Text;
                s.FacultyID = int.Parse(cmbKhoa.SelectedValue.ToString());
                s.AverageScore = float.Parse(txtDiemTB.Text);

                context.Student.Add(s);
                context.SaveChanges();

                BindGrid(context.Student.ToList());
                MessageBox.Show("Thêm mới dữ liệu thành công!", "Thông báo");
                ResetForm();
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                Student dbUpdate = context.Student.FirstOrDefault(p => p.StudentID == txtMaSV.Text);

                if (dbUpdate != null)
                {
                    dbUpdate.FullName = txtHoTen.Text;
                    dbUpdate.FacultyID = int.Parse(cmbKhoa.SelectedValue.ToString());
                    dbUpdate.AverageScore = float.Parse(txtDiemTB.Text);

                    context.SaveChanges();

                    BindGrid(context.Student.ToList());
                    MessageBox.Show("Cập nhật dữ liệu thành công!", "Thông báo");
                    ResetForm();
                }
                else
                {
                    MessageBox.Show("Không tìm thấy MSSV cần sửa!", "Thông báo");
                }
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            Student dbDelete = context.Student.FirstOrDefault(p => p.StudentID == txtMaSV.Text);

            if (dbDelete != null)
            {
                DialogResult dr = MessageBox.Show("Bạn có muốn xóa sinh viên này?", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    context.Student.Remove(dbDelete);
                    context.SaveChanges();

                    BindGrid(context.Student.ToList());
                    MessageBox.Show("Xóa sinh viên thành công!", "Thông báo");
                    ResetForm();
                }
            }
            else
            {
                MessageBox.Show("Không tìm thấy MSSV cần xóa!", "Thông báo");
            }
        }

        private void dgvSinhVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvSinhVien.Rows[e.RowIndex];
                txtMaSV.Text = row.Cells[0].Value.ToString();
                txtHoTen.Text = row.Cells[1].Value.ToString();
                cmbKhoa.Text = row.Cells[2].Value.ToString();
                txtDiemTB.Text = row.Cells[3].Value.ToString();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}